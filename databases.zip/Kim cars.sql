CREATE TABLE cars (
brand VARCHAR(225),
model VARCHAR (225),
year INT
);



INSERT INTO cars (brand, model, year)
VALUES('Ford', 'Mustang', 1964);
SELECT* FROM cars;
SELECT brand, year FROM cars;


